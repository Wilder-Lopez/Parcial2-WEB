
@section('content')
<div class="container">

<a href="{{ url('Productos/create')}}" class="btn btn-success">Agregar Productos</a>
<br/>
<br/>

<table class="table table-light">

    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            <th>Presentacion</th>
            <th>PrecioCosto</th>
            <th>FechaIngreso</th>
            <th>cantidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    
    <tbody>
    
    @foreach ($Productos as $Productos)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$Productos->Nombre}}</td>
            <td>{{$Productos->Descripcion}}</td>
            <td>{{$Productos->Presentacion}}</td>
            <td>{{$Productos->PrecioCosto}}</td>
            <td>{{$Productos->FechaIngreso}}</td>
            <td>{{$Productos->cantidad}}</td>
            <td>Editar | Borrar </td>

        </tr>
    @endforeach
    
    </tbody>
</table>

<main  class="py-4">

@yield('content')
</main>
</div>