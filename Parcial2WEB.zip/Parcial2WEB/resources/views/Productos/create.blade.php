//Seccion para crear productos

<form action="{{ URL('/Productos')}}" method="post" class="form-horizontal">
@csrf
{{ csrf_field() }}

<label for="Nombre">{{'Nombre'}}</label>
<input type="text" name="Nombre" id="Nombre" value="">
<br/>

<label for="Descripcion">{{'Descripcion'}}</label>
<input type="text" name="Descripcion" id="Descripcion" value="">
</br>

<label for="Presentacion">{{'Presentacion'}}</label>
<input type="text" name="Presentacion" id="Presentacion" value="">
</br>

<label for="Proveedor">{{'Proveedor'}}</label>
<input type="text" name="Proveedor" id="Proveedor" value="">
</br>

<label for="FechaIngreso">{{'Proveedor'}}</label>
<input type="date" name="FechaIngreso" id="FechaIngreso" value="">
</br>

<label for="PrecioCosto">{{'PrecioCosto'}}</label>
<input type="decimal" name="PrecioCosto" id="PrecioCosto" value="">
</br>

<label for="cantidad">{{'cantidad'}}</label>
<input type="integer" name="cantidad" id="cantidad" value="">
</br>

<input type="submit" value="Agregar">
</form>
