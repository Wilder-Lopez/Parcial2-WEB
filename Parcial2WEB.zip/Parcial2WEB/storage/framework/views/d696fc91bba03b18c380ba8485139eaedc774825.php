//Seccion para crear productos

<form action="<?php echo e(URL('/Productos')); ?>" method="post" class="form-horizontal">
<?php echo csrf_field(); ?>
<?php echo e(csrf_field()); ?>


<label for="Nombre"><?php echo e('Nombre'); ?></label>
<input type="text" name="Nombre" id="Nombre" value="">
<br/>

<label for="Descripcion"><?php echo e('Descripcion'); ?></label>
<input type="text" name="Descripcion" id="Descripcion" value="">
</br>

<label for="Presentacion"><?php echo e('Presentacion'); ?></label>
<input type="text" name="Presentacion" id="Presentacion" value="">
</br>

<label for="Proveedor"><?php echo e('Proveedor'); ?></label>
<input type="text" name="Proveedor" id="Proveedor" value="">
</br>

<label for="FechaIngreso"><?php echo e('Proveedor'); ?></label>
<input type="date" name="FechaIngreso" id="FechaIngreso" value="">
</br>

<label for="PrecioCosto"><?php echo e('PrecioCosto'); ?></label>
<input type="decimal" name="PrecioCosto" id="PrecioCosto" value="">
</br>

<label for="cantidad"><?php echo e('cantidad'); ?></label>
<input type="integer" name="cantidad" id="cantidad" value="">
</br>

<input type="submit" value="Agregar">
</form>
<?php /**PATH C:\xampp\htdocs\Parcial2WEB\resources\views/Productos/create.blade.php ENDPATH**/ ?>