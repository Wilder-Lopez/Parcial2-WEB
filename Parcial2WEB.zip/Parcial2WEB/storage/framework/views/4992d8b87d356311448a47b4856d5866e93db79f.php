
<?php $__env->startSection('content'); ?>
<div class="container">

<a href="<?php echo e(url('Productos/create')); ?>" class="btn btn-success">Agregar Productos</a>
<br/>
<br/>

<table class="table table-light">

    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            <th>Presentacion</th>
            <th>PrecioCosto</th>
            <th>FechaIngreso</th>
            <th>cantidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    
    <tbody>
    
    <?php $__currentLoopData = $Productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($Productos->Nombre); ?></td>
            <td><?php echo e($Productos->Descripcion); ?></td>
            <td><?php echo e($Productos->Presentacion); ?></td>
            <td><?php echo e($Productos->PrecioCosto); ?></td>
            <td><?php echo e($Productos->FechaIngreso); ?></td>
            <td><?php echo e($Productos->cantidad); ?></td>
            <td>Editar | Borrar </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
</table>

<main  class="py-4">

<?php echo $__env->yieldContent('content'); ?>
</main>
</div><?php /**PATH C:\xampp\htdocs\Parcial2WEB\resources\views/Productos/Index.blade.php ENDPATH**/ ?>